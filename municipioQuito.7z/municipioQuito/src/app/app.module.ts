import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { ListPage } from '../pages/list/list';
import { TrolebusPage} from '../pages/trolebus/trolebus';
import { EcoviaPage } from '../pages/ecovia/ecovia';
import { SuroccidentalPage} from '../pages/suroccidental/suroccidental';
import { IntegracionPage} from '../pages/integracion/integracion';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    ListPage,
    TrolebusPage,
    EcoviaPage,
    SuroccidentalPage,
    IntegracionPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    ListPage,
    TrolebusPage,
    EcoviaPage,
    SuroccidentalPage,
    IntegracionPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}
