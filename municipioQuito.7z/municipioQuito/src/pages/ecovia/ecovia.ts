import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the EcoviaPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-ecovia',
  templateUrl: 'ecovia.html',
})
export class EcoviaPage {
  paradasBuses = [];
  constructor(public navCtrl: NavController, public navParams: NavParams) {

    this.paradasBuses.push({
      nombre: 'Casa de la Cultura',
      img:'../../assets/imgs/ecovia/ecovia1.jpg',
      ubicacion:'Av 6 de Diciembre y Patria',
      lugarReferencial: 'Casa de la Cultura',
      tiempoEstimado: '18m (10 Kilometros)',
      tipo:'Parada Doble Direcciòn'
    });

    this.paradasBuses.push({
      nombre: 'Galo Plaza',
      img:'../../assets/imgs/ecovia/ecovia2.jpg',
      ubicacion:'Av 6 de Diciembre y Gral Robles',
      lugarReferencial: 'Hotel 6 de Diciembre',
      tiempoEstimado: '40m (12 Kilometros)',
      tipo:'Parada Doble Direcciòn'
    });

    this.paradasBuses.push({
      nombre: 'De las Universidades',
      img:'../../assets/imgs/ecovia/ecovia3.jpg',
      ubicacion:'Av 12 de Octubre y Gabriel Ignacio de Veintimilla',
      lugarReferencial: 'Universidad Catòlica del Ecuador',
      tiempoEstimado: '60m (28 Kilometros)',
      tipo:'Parada una sola Direcciòn'
    });


    this.paradasBuses.push({
      nombre: 'Playon de la Marin',
      img:'../../assets/imgs/ecovia/ecovia4.jpg',
      ubicacion:'Av Pichincha y Los Rios',
      lugarReferencial: 'Terminal Cumanda',
      tiempoEstimado: '1h 25m (35 Kilometros)',
      tipo:'Terminal de Transferencia'
    });


  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad EcoviaPage');
  }

}
