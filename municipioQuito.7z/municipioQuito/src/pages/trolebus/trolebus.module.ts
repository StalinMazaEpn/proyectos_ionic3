import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TrolebusPage } from './trolebus';

@NgModule({
  declarations: [
    TrolebusPage,
  ],
  imports: [
    IonicPageModule.forChild(TrolebusPage),
  ],
})
export class TrolebusPageModule {}
