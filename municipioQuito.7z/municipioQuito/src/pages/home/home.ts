import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  paginasSlide = [];
  constructor(public navCtrl: NavController) {


    this.paginasSlide.push({
      nombre: 'Circuitos de Transporte',
      img:'../../assets/imgs/municipio/municipio1.jpg',
      descripcion:'Alcaldia de Quito'
    });

    this.paginasSlide.push({
      nombre: 'Mejores Administraciones Zonales',
      img:'../../assets/imgs/municipio/municipio2.jpg',
      descripcion:'Siempre acercandonos a la gente'
    });

    this.paginasSlide.push({
      nombre: 'Reuniòn de Consejo',
      img:'../../assets/imgs/municipio/municipio3.jpg',
      descripcion:'Se busca aprobar la reforma en el cabildo.'
    });

    this.paginasSlide.push({
      nombre: 'Metro de Quito',
      img:'../../assets/imgs/municipio/municipio4.jpg',
      descripcion:'El Metro de Quito tiene un avance del 15%'
    });
  }

}
