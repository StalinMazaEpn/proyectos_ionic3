import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SuroccidentalPage } from './suroccidental';

@NgModule({
  declarations: [
    SuroccidentalPage,
  ],
  imports: [
    IonicPageModule.forChild(SuroccidentalPage),
  ],
})
export class SuroccidentalPageModule {}
