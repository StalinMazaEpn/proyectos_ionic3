import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { IntegracionPage } from './integracion';

@NgModule({
  declarations: [
    IntegracionPage,
  ],
  imports: [
    IonicPageModule.forChild(IntegracionPage),
  ],
})
export class IntegracionPageModule {}
