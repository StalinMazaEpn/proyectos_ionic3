import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the TrolebusPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-trolebus',
  templateUrl: 'trolebus.html',
})
export class TrolebusPage {

  paradasBuses = [];

  constructor(public navCtrl: NavController, public navParams: NavParams) {

    this.paradasBuses.push({
      nombre: 'Parque el Ejido',
      img:'../../assets/imgs/trolebus/trolebus1.jpg',
      ubicacion:'Av 10 de Agosto y Patria',
      lugarReferencial: 'Puente del Guambra',
      tiempoEstimado: '12m (5 Kilometros)',
      tipo:'Parada 1 Sola Direcciòn'
    });

    this.paradasBuses.push({
      nombre: 'Colon',
      img:'../../assets/imgs/trolebus/trolebus2.jpg',
      ubicacion:'Av 10 de Agosto y Colon',
      lugarReferencial: 'KFC Colon',
      tiempoEstimado: '30m (18 Kilometros)',
      tipo:'Punto de Transferencia'
    });

    this.paradasBuses.push({
      nombre: 'El Labrador',
      img:'../../assets/imgs/trolebus/trolebus3.jpg',
      ubicacion:'Av 10 de Agosto y Av Amazonas',
      lugarReferencial: 'Antiguo Aeropuerto de Quito',
      tiempoEstimado: '60m (28 Kilometros)',
      tipo:'Terminal de Transferencia'
    });


    this.paradasBuses.push({
      nombre: 'Cumanda',
      img:'../../assets/imgs/trolebus/trolebus4.jpg',
      ubicacion:'Bolivar y Quijano',
      lugarReferencial: 'Terminal Cumanda',
      tiempoEstimado: '1h 25m (35 Kilometros)',
      tipo:'Parada 1 Sola Direcciòn'
    });

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad TrolebusPage');
  }

}
