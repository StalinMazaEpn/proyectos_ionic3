import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the SuroccidentalPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-suroccidental',
  templateUrl: 'suroccidental.html',
})
export class SuroccidentalPage {

  paradasBuses = [];
  constructor(public navCtrl: NavController, public navParams: NavParams) {

    this.paradasBuses.push({
      nombre: 'Seminario Mayor',
      img:'../../assets/imgs/surO/surO1.jpg',
      ubicacion:'Av America y Colon',
      lugarReferencial: 'Universidad Central',
      tiempoEstimado: '45m (15 Kilometros)',
      tipo:'Punto de Transferencia'
    });

    this.paradasBuses.push({
      nombre: 'CSW Hospital de IESS',
      img:'../../assets/imgs/surO/surO2.jpg',
      ubicacion:'Av Universitaria y 18 de Septiembre',
      lugarReferencial: 'Hospital Carlos Andrade Marin',
      tiempoEstimado: '30m (18 Kilometros)',
      tipo:'Parada 1 Sola Direcciòn'
    });

    this.paradasBuses.push({
      nombre: 'Dos Puentes',
      img:'../../assets/imgs/surO/surO3.jpg',
      ubicacion:'Francisco Barba y Alberto Enriquez',
      lugarReferencial: 'MiniMercado Juanito',
      tiempoEstimado: '60m (28 Kilometros)',
      tipo:'Parada 1 Sola Direcciòn'
    });


    this.paradasBuses.push({
      nombre: 'Ajavi',
      img:'../../assets/imgs/surO/surO4.jpg',
      ubicacion:'Ajavi y Paquisha',
      lugarReferencial: 'Viena Pizzeria',
      tiempoEstimado: '1h 35m (29 Kilometros)',
      tipo:'Parada 1 Sola Direcciòn'
    });

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SuroccidentalPage');
  }

}
