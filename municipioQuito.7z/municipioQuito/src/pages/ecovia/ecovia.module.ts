import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EcoviaPage } from './ecovia';

@NgModule({
  declarations: [
    EcoviaPage,
  ],
  imports: [
    IonicPageModule.forChild(EcoviaPage),
  ],
})
export class EcoviaPageModule {}
