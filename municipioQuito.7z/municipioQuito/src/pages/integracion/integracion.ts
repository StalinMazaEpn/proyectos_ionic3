import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the IntegracionPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-integracion',
  templateUrl: 'integracion.html',
})
export class IntegracionPage {

  paradasBuses = [];

  constructor(public navCtrl: NavController, public navParams: NavParams) {

    this.paradasBuses.push({
      nombre: 'Ecovia - Quitumbe',
      img:'../../assets/imgs/integracion/integracion1.jpg',
      ubicacion:'Pedro Vicente Maldonado y Leonidas Dubles',
      lugarReferencial: 'Terminal Guamani',
      tiempoEstimado: '25m (12 Kilometros)',
      tipo:'Punto de Transferencia'
    });

    this.paradasBuses.push({
      nombre: 'Magdalena - Magdalena',
      img:'../../assets/imgs/integracion/integracion2.jpg',
      ubicacion:'Mariscal Sucre y Arenillas',
      lugarReferencial: 'Viveres ABI',
      tiempoEstimado: '17m (12 Kilometros)',
      tipo:'Punto de Transferencia'
    });

    this.paradasBuses.push({
      nombre: 'Magdalena - Chimbacalle',
      img:'../../assets/imgs/integracion/integracion3.jpg',
      ubicacion:'Pedro Vicente Maldonado y LLanganates',
      lugarReferencial: 'Teatro Mexico',
      tiempoEstimado: '60m (28 Kilometros)',
      tipo:'Punto de Transferencia'
    });


    this.paradasBuses.push({
      nombre: 'Rio Coca - Norte',
      img:'../../assets/imgs/integracion/integracion4.jpg',
      ubicacion:'Av 6 de Diciembre y Rio Coca',
      lugarReferencial: 'Granados Plaza',
      tiempoEstimado: '1h 35m (29 Kilometros)',
      tipo:'Punto de Transferencia'
    });

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad IntegracionPage');
  }

}
